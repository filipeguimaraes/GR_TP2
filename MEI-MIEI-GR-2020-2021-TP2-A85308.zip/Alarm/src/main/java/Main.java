/**
 * Ponto de partida da aplicação.
 *
 * @author Filipe Miguel Teixeira Freitas Guimarães - A865308
 */
public class Main {

    /**
     * Iniciar o programa. Funcionalmente sem utilidade. Apenas para compatibilidade com o javaFX.
     *
     * @param args Argumentos.
     */
    public static void main(final String[] args) {
        MainFX.main(args);
    }
}
